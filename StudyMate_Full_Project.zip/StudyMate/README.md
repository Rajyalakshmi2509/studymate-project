# StudyMate

AI-powered PDF Q&A system using Streamlit, PyMuPDF, FAISS, and HuggingFace.