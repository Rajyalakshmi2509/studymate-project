import streamlit as st
import fitz  # PyMuPDF
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer
import requests
import os

st.set_page_config(page_title="StudyMate", layout="centered")
st.title("📘 StudyMate: AI-Powered PDF-Based Q&A")

# --- Hugging Face API Key ---
HF_TOKEN = st.secrets.get("HF_TOKEN") or os.getenv("HF_TOKEN")
HF_API_URL = "https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.1"

headers = {"Authorization": f"Bearer {HF_TOKEN}"}


# --- Functions ---
@st.cache_data(show_spinner=False)
def extract_text_from_pdf(uploaded_file):
    doc = fitz.open(stream=uploaded_file.read(), filetype="pdf")
    text = ""
    for page in doc:
        text += page.get_text()
    return text


@st.cache_resource
def load_embedder():
    return SentenceTransformer("all-MiniLM-L6-v2")


@st.cache_data
def chunk_text(text, chunk_size=500, overlap=50):
    words = text.split()
    chunks = []
    for i in range(0, len(words), chunk_size - overlap):
        chunk = " ".join(words[i:i + chunk_size])
        chunks.append(chunk)
    return chunks


@st.cache_data
def create_faiss_index(chunks, embedder):
    embeddings = embedder.encode(chunks, convert_to_numpy=True)
    index = faiss.IndexFlatL2(embeddings.shape[1])
    index.add(embeddings)
    return index, embeddings


def search_similar_chunks(query, chunks, index, embedder, top_k=3):
    query_embedding = embedder.encode([query])
    D, I = index.search(np.array(query_embedding), top_k)
    return [chunks[i] for i in I[0]]


def ask_huggingface(question, context):
    prompt = f"Answer the question based on the context below:\n\nContext:\n{context}\n\nQuestion:\n{question}\n\nAnswer:"
    payload = {
        "inputs": prompt,
        "parameters": {"max_new_tokens": 200, "temperature": 0.7},
    }
    response = requests.post(HF_API_URL, headers=headers, json=payload)
    if response.status_code == 200:
        return response.json()[0]['generated_text'].split("Answer:")[-1].strip()
    else:
        return "Failed to get a response from the model."


# --- UI Workflow ---
uploaded_file = st.file_uploader("Upload your academic PDF", type=["pdf"])
query = st.text_input("Ask a question based on the document")

if uploaded_file and query:
    with st.spinner("Processing..."):
        text = extract_text_from_pdf(uploaded_file)
        chunks = chunk_text(text)
        embedder = load_embedder()
        index, _ = create_faiss_index(chunks, embedder)
        top_chunks = search_similar_chunks(query, chunks, index, embedder)
        combined_context = " ".join(top_chunks)
        answer = ask_huggingface(query, combined_context)

    st.subheader("📌 Answer:")
    st.write(answer)

    with st.expander("🔍 Top Matching Context Chunks"):
        for i, chunk in enumerate(top_chunks, 1):
            st.markdown(f"**Chunk {i}:** {chunk[:500]}...")
